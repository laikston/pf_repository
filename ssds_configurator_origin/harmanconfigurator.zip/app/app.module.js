angular.module('harmanConfiguration', ['ui.router'])

.config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/configStart");
    //rutes configuration using ui.router

    var configStart = {
        name: 'configStart',
        url: '/configStart',
        templateUrl: 'app/views/app.config-start.html',
        controller: 'configStartController'
    };

    var configOne = {
        name: 'configOne',
        url: '/configOne',
        templateUrl: 'app/views/app.config-one.html',
        controller: 'configOneController'
    };
    var configTwo = {
        name: 'configTwo',
        url: '/configTwo',
        templateUrl: 'app/views/app.config-two.html',
        controller: 'configTwoController'
    };
    var configThree = {
        name: 'configThree',
        url: '/configThree',
        templateUrl: 'app/views/app.config-three.html',
        controller: 'configThreeController'
    };
    var configFour = {
        name: 'configFour',
        url: '/configFour',
        templateUrl: 'app/views/app.config-four.html',
        controller: 'configFourController'
    };
    var configHuddleSpecs = {
        name: 'configHuddleSpecs',
        url: '/configHuddleSpecs',
        templateUrl: 'app/views/app.config-huddleSpecs.html',
        controller: 'configHuddleSpecsController'
    };
    $stateProvider.state(configStart);
    $stateProvider.state(configOne);
    $stateProvider.state(configTwo);
    $stateProvider.state(configThree);
    $stateProvider.state(configFour);
    $stateProvider.state(configHuddleSpecs);
});