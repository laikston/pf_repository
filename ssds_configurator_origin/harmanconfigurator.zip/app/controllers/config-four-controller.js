angular.module('harmanConfiguration').controller('configFourController', ['$scope', 'configService', '$state', '$window', function($scope, configService, $state, $window) {
    /*funtions*/
    configService.interactionMenu('fourConfiguration', 'iconsSelectVibeColor');
    $scope.stateGo = stateGo;
    // $scope.stateGoSpecs = stateGoSpecs;
    $scope.goToHarman = goToHarman;
    $scope.toggleClass = toggleClass;
    $scope.getValue = getValue;
    $scope.goToHuddleInteractive = goToHuddleInteractive;
    $scope.goToHuddleCore = goToHuddleCore;
    $scope.showScheduleMonitor = showScheduleMonitor;
    //$scope.stateGo = stateGo;
    /*variables*/
    $scope.showMonitor = false;
    $scope.showAcendoVibe = false;
    $scope.nextButtom = false;
    $scope.selectScreenSize = false;
    $scope.showRoomElements = true;
    $scope.showConfigIcon = true;
    $scope.screenCapabilities = false;
    $scope.space = configService.space;
    $scope.imageIcon = "touch-screen";
    $scope.vibeCore = "vibe-core";
    $scope.showSize = false;
    $scope.bookView = false;
    //set my own values from configService.
    $scope.questionExtra = configService.head.questions.questionExtra;
    $scope.title = configService.head.title;
    $scope.question = configService.head.questions.questionFour;
    $scope.urlBack = configService.head.url.configThree;

    configService.screenSize = 49;
    $scope.imageVibe = configService.configuration.vibeColor[configService.vibeColor.toLowerCase()].class;
    $scope.imageMonitor = configService.configuration.screenSize[configService.screenSize].class[1];
    $scope.huddleType= configService.configuration.huddle.huddleCore.name;
    var screenType = "";

    /*change class in my nav*/
    function toggleClass(event) {
        if (!$scope.screenCapabilities) {
            //document.getElementById("screenCapabilities").style.visibility = "hidden";
        }
        configService.toggleClass(event);
        
        
    }

    function getValue(event) {
        var value = event.srcElement.innerHTML;
        if (parseInt(value) > 0) {
            configService.screenSize = parseInt(value);
            if($scope.scheduleMonitor ==true){
                // $scope.imageMonitor = configService.configuration.screenSize[configService.screenSize].class[1] + "  add-schedule-view";
                $scope.imageMonitor = screenType+"-"+configService.screenSize+"-"+ configService.vibeColor.toLowerCase()+ "  add-schedule-view";
            }else{
                $scope.imageMonitor = screenType+"-"+configService.screenSize+"-"+ configService.vibeColor.toLowerCase();
            }
        } else {
            configService.vibeColor = value;
            
            if($scope.scheduleMonitor == true){
                //$scope.imageVibe = configService.configuration.vibeColor[configService.vibeColor.toLowerCase()].class +  " add-schedule-view";
                $scope.imageMonitor = screenType+"-"+configService.screenSize+"-"+ configService.vibeColor.toLowerCase()+ "  add-schedule-view";
            }else{
                $scope.imageMonitor = screenType+"-"+configService.screenSize+"-"+ configService.vibeColor.toLowerCase();
            }
        }
    }
 
    function stateGo() {
        $state.go('configStart');
    }

     function stateGoSpecs() {
        console.log("going to specs");
        $state.go('configHuddleSpecs');
    }

    function goToHarman(){
        function escapeRegExp(str) {
            return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
        }
        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
        }

        var url = "https://www.amx.com/en-US/products/";
        var huddle = configService.configuration.huddle[configService.configuration.selectedHuddle].name.split(" :")[0];
        huddle = replaceAll(huddle, " ", "-");
        huddle = huddle.toLowerCase();
        $window.location.href = url + huddle + "-solution";
    }

    function goToHuddleCore(){
        $scope.showConfigIcon = false
        $scope.showMonitor = true;
        $scope.showAcendoVibe = true;
        $scope.selectScreenSize = true; 
        $scope.nextButtom=true;
        $scope.action ="REstart tool";
        $scope.restartButton = true;
        $scope.showSize = false;
        $scope.screenCapabilities=true;
        $scope.huddleType= configService.configuration.huddle.huddleCore.name;
        $scope.showHuddle = true;
        $scope.detailIcon = true;
        configService.configuration.setup.touchEnabled = false;
        $scope.showRecommendedHuddleBg = true;
        screenType = "tv-acendo-core";
        $scope.imageMonitor = screenType+"-"+configService.screenSize+"-"+ configService.vibeColor.toLowerCase();
        configService.configuration.selectedHuddle = "huddleCore";
    }



    function goToHuddleInteractive(){
        $scope.showConfigIcon = false
        $scope.showMonitor = true;
        $scope.showAcendoVibe = true;
        $scope.selectScreenSize = true; 
        $scope.nextButtom=true; 
        $scope.action ="REstart tool";
        $scope.restartButton = true;
        $scope.huddleType= configService.configuration.huddle.huddleInteractive.name;
        $scope.showSize = true;
        $scope.showHuddle = true;
        $scope.detailIcon = true;
        configService.configuration.setup.touchEnabled = true;
        $scope.showRecommendedHuddleBg = true;
        screenType = "tv-interactive";
        configService.screenSize = "55";
        $scope.imageMonitor = screenType+"-55-"+ configService.vibeColor.toLowerCase();
        configService.configuration.selectedHuddle = "huddleInteractive";
    }

    function showScheduleMonitor(){
        $scope.bookView = false;
        $scope.scheduleMonitor = true;
        $scope.showScheduleView = true;
        $scope.scheduleMonitorView = true;
        $scope.space +=  " add-schedule-view";
        $scope.addScheduleView = " add-schedule-view";
        $scope.imageMonitor = screenType+"-"+configService.screenSize+"-"+ configService.vibeColor.toLowerCase()+ "  add-schedule-view";
    }

    function init(){
        if(configService.configuration.setup.conferencingCollaborating == false){
            $state.go('configThree');
        }
    }

    init();


}]);