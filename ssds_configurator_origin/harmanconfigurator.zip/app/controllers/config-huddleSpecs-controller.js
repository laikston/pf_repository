angular.module('harmanConfiguration').controller('configHuddleSpecsController', ['$scope', 'configService', '$sce', '$state', "$window", function($scope, configService, $sce , $state, $window) {
    /*funtions*/
    $scope.stateGo = stateGo;

    function goToSamsung(){

        $window.location.href = "http://displaysolutions.samsung.com/";
    }

    function goToHarman(){
        function escapeRegExp(str) {
            return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
        }
        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
        }

        var url = "https://www.amx.com/en-US/products/";
        var huddle = configService.configuration.huddle[configService.configuration.selectedHuddle].name.split(" :")[0];
        huddle = replaceAll(huddle, " ", "-");
        huddle = huddle.toLowerCase();
        $window.location.href = url + huddle + "-solution";
    }

    function displayScreen(){
        var color = "";
        if(configService.vibeColor == "black"){
            color = "black";
        }else{
            color = "silver";            
        }
        switch(configService.configuration.selectedHuddle){
            case "huddleView":
                $scope.tvViewer = "huddle-stardard";
            break;
            case "huddleVibe":
                $scope.tvViewer = "huddle-premium-"+color;
            break;
            case "huddleCore":
                $scope.tvViewer = "huddle-enterprise-"+color;
            break;
            case "huddleInteractive":
                $scope.tvViewer = "huddle-enterprise-plus-"+color;
            break;
            default:
                $scope.tvViewer = "";
            break;

        }
    }

    $scope.insertKeyFeatures = function() {
               return $sce.trustAsHtml($scope.keyFeatures);
             };

    function stateGo() {
         $state.go('configStart');
    }

    function init(){
       //TODO
        if(configService.configuration.selectedHuddle == ""){
            $state.go('configOne');
        }else{
            $scope.huddleName = configService.configuration.huddle[configService.configuration.selectedHuddle].name.split(":")[0];
            $scope.keyFeatures = configService.configuration.huddle[configService.configuration.selectedHuddle].features;
            $scope.goToSamsung = goToSamsung;
            $scope.goToHarman = goToHarman;

            displayScreen();
        }
        
    }
    init();
    //console.log(configService);
}]);