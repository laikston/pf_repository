angular.module('harmanConfiguration').controller('configOneController', ['$scope', 'configService', '$state', function($scope, configService, $state) {
    /*funtions*/
    configService.interactionMenu('firstConfiguration');
    $scope.changeViews = changeViews;
    $scope.stateGo = stateGo;

    /*variables*/
    $scope.showContactUsToday = false;
    $scope.nextButtom = true;
    $scope.nextPopup = false;
    $scope.action = "Next";
    $scope.showRoomElements = true;
    $scope.showConfigIcon = true;
    $scope.title = configService.head.title;
    $scope.question = configService.head.questions.questionOne;
    $scope.urlNext = configService.head.url.configTwo;
    $scope.configuration = configService.configuration;
    $scope.space = configService.space;
    $scope.imageIcon = "seats";
    configService.screenSize = 40;
    $scope.showBorders = configService.configuration.space.nineMore.status;


    function changeViews(property, value) {
        $scope.nextPopup = false;
        if (value == configService.configuration.space.nineMore.class) {
            configService.space = configService.configuration.space.nineMore.class;
            $scope.showBorders = configService.configuration.space.nineMore.status = true;
            $scope.showContactUsToday = true;
            $scope.showRoomElements = false;
            $scope.nextButtom = false;
            $scope.hideBG = true;

        } else {
            $scope.hideBG = false;
            $scope.nextButtom = true;
            if (value == configService.configuration.space.twoFour.class) {
                configService.space = configService.configuration.space.twoFour.class;
                configService.configuration.space.twoFour.status = true;
                configService.configuration.space.fiveEight.status = false;
            }
            if (value == configService.configuration.space.fiveEight.class) {
                configService.space = configService.configuration.space.fiveEight.class;
                configService.configuration.space.twoFour.status = false;
                configService.configuration.space.fiveEight.status = true;
            }
            $scope.showContactUsToday = false;
            $scope.showRoomElements = true;
            $scope.showBorders = configService.configuration.space.nineMore.status = false;
        }
        configService.currentConfigurator(property, value);
        $scope.space = configService.space;
    }

    function stateGo() {
        console.log($scope.urlNext);
        console.log(configService.space);
        if($scope.space == ""){
            $scope.nextPopup = true;
        }else{
            $state.go($scope.urlNext);
        }
        
    }

    function init(){
        // if (configService.space == ""){
        //     configService.space = "one2-4";
             $scope.space = configService.space;
        // }
        
    }
    init();
    console.log(configService);
    //TODO: when comming back from question 2, keep selected the option of seats previously choosen

}]);