angular.module('harmanConfiguration').controller('configStartController', ['$scope', 'configService', '$state', function($scope, configService, $state) {
    /*functions*/
    $scope.stateGo = stateGo;
    
    /*variables*/
    configService.space = "welcome";
    $scope.space = configService.space;
    $scope.urlNext = configService.head.url.configOne;
    $scope.showRoomElements = true;

    function stateGo() {
        $state.go($scope.urlNext);
        configService.space = 'one2-4';
    }
    
}]);