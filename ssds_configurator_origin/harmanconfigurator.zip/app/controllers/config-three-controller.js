angular.module('harmanConfiguration').controller('configThreeController', ['$scope', 'configService', '$state', '$window', function($scope, configService, $state, $window) {
    /*funtions*/
    $scope.toggleClass = toggleClass;
    $scope.stateGo = stateGo;
    $scope.stateGoNext = stateGoNext;
    // $scope.stateGoSpecs = stateGoSpecs;
    $scope.goToHarman = goToHarman;
    $scope.getValue = getValue;
    $scope.goToHuddleVibe = goToHuddleVibe;
    $scope.showScheduleMonitor = showScheduleMonitor;
    
    /*funtions*/
    /*variables*/
    //ng-show
    $scope.showMonitor = false;
    $scope.showAcendoVibe = false;
    $scope.nextButtom = false;
    $scope.selectScreenSize = false;
    $scope.showRoomElements = true;
    $scope.showConfigIcon = true;
    $scope.space = configService.space;
    //set my own values from configService.
    $scope.questionExtra = configService.head.questions.questionExtra;
    $scope.title = configService.head.title;
    $scope.question = configService.head.questions.questionThree;
    $scope.urlNext = configService.head.url.configFour;
    $scope.urlBack = configService.head.url.configTwo;
    $scope.imageIcon = "screen";
    configService.screenSize = 49;
    $scope.imageVibe = configService.configuration.vibeColor[configService.vibeColor.toLowerCase()].class;
    $scope.imageMonitor = configService.configuration.screenSize[configService.screenSize].class[0];
    $scope.huddleType = configService.configuration.huddle.huddleVibe.name;

    /*variables*/
    $scope.bookView = false;

    /*Service*/
    configService.configuration.setup.conferencingCollaborating = false;


    function toggleClass(event) {
        configService.toggleClass(event);
        


    }

    function stateGo() {
        $state.go('configStart');
    }

    function stateGoNext() {
        configService.configuration.setup.conferencingCollaborating = true;
        $state.go('configFour');
    }

     function stateGoSpecs() {
        console.log("going to specs");
        $state.go('configHuddleSpecs');
    }

    function getValue(event) {
        var value = event.srcElement.innerHTML;
        if (parseInt(value) > 0) {
            configService.screenSize = parseInt(value);
            if($scope.scheduleMonitor ==true){
                 //$scope.imageMonitor = configService.configuration.screenSize[configService.screenSize].class[0] + " add-schedule-view";
                  $scope.imageMonitor = "tv-"+configService.screenSize+"in-"+ configService.vibeColor.toLowerCase() + " add-schedule-view";
            }else{
                //$scope.imageMonitor = configService.configuration.screenSize[configService.screenSize].class[0];
                $scope.imageMonitor = "tv-"+configService.screenSize+"in-"+ configService.vibeColor.toLowerCase();
            }
        } else {
            configService.vibeColor = value;
            
            if($scope.scheduleMonitor ==true){
                //$scope.imageVibe = configService.configuration.vibeColor[configService.vibeColor.toLowerCase()].class +  " add-schedule-view";
                $scope.imageMonitor = "tv-"+configService.screenSize+"in-"+ configService.vibeColor.toLowerCase() + " add-schedule-view";
            }else{
                //$scope.imageVibe = configService.configuration.vibeColor[configService.vibeColor.toLowerCase()].class;
                $scope.imageMonitor = "tv-"+configService.screenSize+"in-"+ configService.vibeColor.toLowerCase();
            }
            
        }
    }

    function goToHuddleVibe() {
        $scope.showConfigIcon = false
        $scope.showMonitor = true;
        $scope.showAcendoVibe = true;
        $scope.showHuddle = true;
        $scope.selectScreenSize = true;
        $scope.nextButtom = true;
        $scope.action ="REstart tool";
        $scope.restartButton = true;
        $scope.detailIcon = true;
        $scope.showRecommendedHuddleBg = true;
        $scope.imageMonitor = "tv-"+configService.screenSize+"in-"+ configService.vibeColor.toLowerCase();
        configService.configuration.selectedHuddle = "huddleVibe";
    }

    function goToHarman(){
        function escapeRegExp(str) {
            return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
        }
        function replaceAll(str, find, replace) {
            return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
        }

        var url = "https://www.amx.com/en-US/products/";
        var huddle = configService.configuration.huddle[configService.configuration.selectedHuddle].name.split(" :")[0];
        huddle = replaceAll(huddle, " ", "-");
        huddle = huddle.toLowerCase();
        $window.location.href = url + huddle + "-solution";
    }

    function showScheduleMonitor(){
        $scope.bookView = false;
        $scope.scheduleMonitor = true;
        $scope.showScheduleView = true;
        $scope.scheduleMonitorView = true;
        $scope.space +=  " add-schedule-view";
        $scope.addScheduleView = " add-schedule-view";
        $scope.imageMonitor = "tv-"+configService.screenSize+"in-"+ configService.vibeColor.toLowerCase() + " add-schedule-view";

    }

    function init(){
        if(configService.configuration.setup.audioQuality == false){
            $state.go('configTwo');
        }
    }

    init();

    console.log(configService);
}]);