angular.module('harmanConfiguration')
    .directive("bookView", function() {
        return {
            restrict: "E",
            templateUrl: 'app/views/app.config-book.html'
        }
    });