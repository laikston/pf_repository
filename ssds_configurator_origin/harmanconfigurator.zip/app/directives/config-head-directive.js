angular.module('harmanConfiguration')
    .directive('viewHead', function() {
        return {
            restrict: 'E',
            templateUrl: 'app/views/app.config-head.html'
        };
    })

angular.module('harmanConfiguration')
    .directive("viewInchColor", ['configService', function(configService) {
        return {
            restrict: "E",
            templateUrl: 'app/views/app.config-inchColor.html',
            link: function(scope, element, attrs) {
                //only in ul.screenCapabilities
                configService.interactionMenu('screenCapabilities');
                //only in ul.vibeColor
                configService.interactionMenu('vibeColor');
            }
        }
    }]);