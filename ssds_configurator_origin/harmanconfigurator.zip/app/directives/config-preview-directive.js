angular.module('harmanConfiguration')
    .directive("viewPreview", ['configService', function(configService) {
        return {
            restrict: "E",
            templateUrl: 'app/views/app.config-preview.html'
        }
    }]);