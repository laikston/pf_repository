angular.module('harmanConfiguration').service('configService', function() {

    this.interactionMenu = function(configClass, notClass) {
        var el = document.querySelectorAll("ul." + configClass + "> li:not(." + notClass + ")");
        for (var i = 0; i < el.length; i++) {
            el[i].addEventListener('click', function() {
                var el_active = document.querySelectorAll("ul." + configClass + "> li.active");
                if (el_active.length > 0) {
                    el_active[0].classList.remove("active");
                }
                this.classList.add("active")
            }, false);
        }
    }
    this.configuration = {
        setup: {
            audioQuality: false,
            conferencingCollaborating: false,
            touchEnabled: false,
            scheduleBook: false
        },
        start: { status: false, class: 'welcome' },
        space: {
            twoFour: { status: false, class: 'one2-4' },
            fiveEight: { status: false, class: 'one5-8' },
            nineMore: { status: false, class: 'contact-us-today' }
        },
        screenSize: {
            '40': { status: false, class: ['tv-audio-40'] },
            // '48': { status: false, class: ['tv-audio-48'] },
            '49': { status: false, class: ['tv-49in', 'tv-acendo-core-49','tv-audio-49'] },
            '55': { status: false, class: ['tv-55in', 'tv-acendo-core-55', 'tv-audio-55'] }
        },
        vibeColor: {
            'black': { status: false, class: 'black' },
            'grey': { status: false, class: 'grey' }
        },
        huddle: {
            huddleView: {
                // "name" : "HUDDLE STANDARD : 49”(DCH series) / 55”(DCJ series)",
                "name" : "HUDDLE STANDARD",
                "features":"<ul > <li>Full solution from single provider</li><li>120° field of view needed for middle size rooms (Logitech 90°)</li>"+
                            "<li>Privacy features (built in shutter, microphone deactivates automatically)</li><li>Ball joint swivel allows for mounting flexibility</li></ul>"
            },
            huddleVibe: {
                // "name" : "HUDDLE PREMIUM : 49”/55” QMH series",
                "name" : "HUDDLE PREMIUM",
                "features":"<ul > <li>Full solution from single provider</li><li>Can turn on display (no remote needed)</li><li>3 year warranty (vs. 1 year)</li>"+
                            "<li>Premium JBL audio</li><li>Offers significant dealer margin</li><li>Emphasis on industrial design</li></ul>"
            },
            huddleCore: {
                // "name" : "HUDDLE ENTERPRISE : 49”/55” QMH series",
                "name" : "HUDDLE ENTERPRISE",
                "features":"<ul > <li>Full solution from single provider</li><li>Built in control of Samsung display remotely (gen 2)</li>"+
                            "<li>Built in Skype and Exchange support; can support most conferencing apps</li>"+
                            "<li>Built-in document viewing</li><li>Screen sharing</li><li>Small footprint</li></ul>"
            }, 
            huddleInteractive: {
                // "name" : "HUDDLE ENTERPRISE PLUS : 55” PMF-BC series",
                "name" : "HUDDLE ENTERPRISE PLUS",
                "features":"<ul > <li>Open platform (not locked into M/S or Cisco S/W)</li><li>Better camera (full field of vision)</li>"+
                            "<li>Better sound quality</li>"+
                            "<li>3 year warranty (vs. 1-2 year)</li><li>More affordable than most whiteboard options</li></ul>"
            }
        },
        selectedHuddle : "",
        scheduleBook: { status: false, class: '' }
    };

    this.space = "";
    this.screenSize = '49';
    this.vibeColor = 'Black';



    this.currentConfigurator = function(property, value) {
        switch (property) {
            case 'space':
                this.space = value;
                break;
            case 'screenSize':
                this.screenSize = value;
                break;
            case 'vibeColor':
                this.vibeColor = value;
                break;
            case 'scheduleBook':
                this.scheduleBook = value;
                break
            default:
                break;
        }
    }
    this.head = {
        title: "HARMAN Configurator",
        questions: {
            questionOne: "How many seats does your meeting room/space have?",
            questionTwo: "Does your application require premium audio quality?",
            questionTwoSub: "(such as externally client facing audio conferences)",
            questionThree: "Do you want conferencing and collaboration capability built into the space?",
            questionFour: "Do you want dynamic control of your meeting through touch screen capabilities?",
            questionExtra: "Do you want to add-on the ability to view room schedule and book ad-hoc meetings from outside the meeting space?",
        },
        url: {
            configOne: "configOne",
            configTwo: "configTwo",
            configThree: "configThree",
            configFour: "configFour",
            configHuddleSpecs: "configHuddleSpecs"
        }
    }
    this.toggleClass = function(event) {
        var activateSubMenu = document.querySelectorAll(".navbar.navbar-default.inchColor");
        if (event.target.querySelectorAll("div")[0] != undefined) {
            document.getElementsByClassName("deactive")[0].classList.add("activated")
            if (event.isTrusted) {
                var isActive = document.getElementsByClassName("isActive");
                while (isActive.length)
                    isActive[0].classList.remove("isActive");
                event.target.querySelectorAll("div")[0].classList.toggle("isActive")
            }
        }
    }
});